"""
MCP tool registry — maps tool names to MCP endpoint URLs and function signatures.

Each MCP server exposes a /mcp endpoint via SSE/streamable-HTTP. We query it
once at startup to discover available tools, then invoke them on demand.
"""

import os
import json
import re
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field
from copy import deepcopy

import httpx

# ── MCP server URLs (all behind nginx on port 8888) ───────────────────────────
MCP_BASE = os.getenv("MCP_BASE", "http://127.0.0.1:8888")
WIKI_MAX_CHARS = int(os.getenv("WIKI_MAX_CHARS", "12000"))


def truncate_text(text: str, max_chars: int = WIKI_MAX_CHARS):
    """Limit text at a sentence boundary when practical."""
    if len(text) <= max_chars:
        return text, False

    shortened = text[:max_chars]
    last_period = shortened.rfind(".")
    if last_period > max_chars // 2:
        shortened = shortened[:last_period + 1]
    return shortened, True


def compact_article_result(result_text: str) -> str:
    """Keep useful article fields and cap the full text for model context."""
    try:
        article = json.loads(result_text)
    except (json.JSONDecodeError, TypeError):
        return result_text
    if not isinstance(article, dict) or not isinstance(article.get("text"), str):
        return result_text

    text, truncated = truncate_text(article["text"])
    compact = {
        key: article[key]
        for key in ("title", "pageid", "summary", "url", "exists")
        if key in article
    }
    compact["text"] = text
    compact["truncated"] = truncated
    return json.dumps(compact, ensure_ascii=False)

TOOLS_CONFIG: List[Dict[str, Any]] = [
    {
        "url": f"{MCP_BASE}/mcp/web-search",
        # Actual tool names on this server: full-web-search, get-web-search-summaries, get-single-web-page-content
        "tools": [
            {"name": "full-web-search", "description": "Search the web and fetch complete page content from top results"},
            {"name": "get-web-search-summaries", "description": "Search the web and return only the search result snippets/descriptions (lightweight)"},
            {"name": "get-single-web-page-content", "description": "Extract full content from a single web page URL"},
        ],
    },
    {
        "url": f"{MCP_BASE}/mcp/wikipedia",
        # Canonical tools exposed by wikipedia-mcp.
        "tools": [
            {"name": "search_wikipedia", "description": "Search Wikipedia for articles"},
            {"name": "get_summary", "description": "Read a Wikipedia article summary"},
            {"name": "get_article", "description": "Read a Wikipedia article"},
        ],
    },
    {
        "url": f"{MCP_BASE}/mcp/time",
        "tools": [
            {"name": "current_time", "description": "Get the current date and time"},
        ],
    },
    {
        "url": f"{MCP_BASE}/mcp/vlc",
        # Actual tool name: open-in-vlc
        "tools": [
            {"name": "open-in-vlc", "description": "Play a stream URL in VLC media player"},
        ],
    },
    {
        "url": f"{MCP_BASE}/mcp/pdf",
        # Actual tool names: read_pdf_text, read_pdf_images
        "tools": [
            {"name": "read_pdf_text", "description": "Extract plain text from a PDF file or URL"},
            {"name": "read_pdf_images", "description": "Render PDF pages as PNG images (base64)"},
        ],
    },
]


@dataclass
class ToolDefinition:
    """OpenAI-compatible tool definition for llama.cpp function calling."""
    type: str = "function"
    name: str = ""
    description: str = ""
    parameters: Dict[str, Any] = field(default_factory=dict)


async def discover_tools(url: str) -> List[Dict[str, Any]]:
    """Query MCP server via JSON-RPC tools/list method to discover tools.

    MCP uses tools/list as a JSON-RPC method sent to the base /mcp URL,
    NOT a separate /tools/list path. Returns SSE response.
    Falls back to config if discovery fails.
    """
    try:
        async with httpx.AsyncClient(
            timeout=5.0,
            headers={"Accept": "application/json, text/event-stream"},
            ) as client:
            r = await client.post(url, json={"jsonrpc": "2.0", "method": "tools/list", "id": 1})
            if r.status_code == 200:
                text = r.text
                # Parse SSE format
                data_match = re.search(r"data:\s*(\{.*\})", text, re.DOTALL)
                if data_match:
                    parsed = json.loads(data_match.group(1))
                else:
                    parsed = json.loads(text.strip())
                return parsed.get("result", {}).get("tools", [])
    except Exception:
        pass
    return []


def parse_mcp_sse_response(raw: str) -> str:
    # Parse SSE-formatted MCP response and extract text content.
    # MCP streamable-HTTP returns:
    #   event: message
    #   id: ...
    #   data: {"result":{"content":[{"type":"text","text":"..."}]}}
    # Also handles plain JSON responses (no SSE wrapping).
    # Try to extract the JSON data line from SSE format
    data_match = re.search(r"data:\s*(\{.*\})", raw, re.DOTALL)
    if data_match:
        parsed = json.loads(data_match.group(1))
    else:
        # Maybe it's already plain JSON
        try:
            parsed = json.loads(raw.strip())
        except json.JSONDecodeError as exc:
            raise RuntimeError("MCP returned invalid JSON.") from exc

    if not isinstance(parsed, dict):
        raise RuntimeError("MCP returned an invalid response.")

    if "error" in parsed:
        raise RuntimeError("MCP returned a JSON-RPC error.")

    result = parsed.get("result")
    if not isinstance(result, dict):
        raise RuntimeError("MCP returned no valid tool result.")

    if result.get("isError"):
        raise RuntimeError("The MCP tool reported a failure.")

    content = result.get("content", [])

    if isinstance(content, list):
        texts = []
        for c in content:
            if isinstance(c, dict):
                if c.get("type") == "text":
                    texts.append(c.get("text", ""))
                elif "text" in c:
                    texts.append(str(c["text"]))
        if texts:
            joined = "\n\n".join(texts)
            return joined

    # Fallback: dump entire result
    return json.dumps(result, ensure_ascii=False, indent=2)[:8000]


async def call_mcp_tool(url: str, tool_name: str, arguments: Dict[str, Any], raise_on_error: bool = True) -> str:
    """Call an MCP tool via the streamable-HTTP protocol.

    Uses the MCP tools/call method. Handles both SSE and plain JSON responses.
    Returns the result as a string.
    """
    payload = {
        "jsonrpc": "2.0",
        "method": "tools/call",
        "id": 1,
        "params": {
            "name": tool_name,
            "arguments": arguments,
        },
    }
    try:
        async with httpx.AsyncClient(
            timeout=120.0,
            headers={"Accept": "application/json, text/event-stream"},
        ) as client:
            response = await client.post(url, json=payload)
            response.raise_for_status()

        result_text = parse_mcp_sse_response(response.text)
        if tool_name == "get_article":
            result_text = compact_article_result(result_text)
        return result_text

    except Exception as exc:
        if raise_on_error:
            raise RuntimeError(
                f"MCP tool '{tool_name}' failed."
            ) from exc

        return f"Error calling {tool_name}: {exc}"


async def build_tool_definitions(*, wikipedia_only=False) -> List[Dict[str, Any]]:
    """Discover real schemas and register the endpoint for each exposed tool."""
    tools = []
    allowed = {"search_wikipedia", "get_summary", "get_article"} if wikipedia_only else None
    for cfg in TOOLS_CONFIG:
        url = cfg["url"]
        if wikipedia_only and not url.endswith("/mcp/wikipedia"):
            continue
        for tool in await discover_tools(url):
            name = tool.get("name")
            if not name or (allowed is not None and name not in allowed):
                continue
            schema = tool.get("inputSchema")
            if not isinstance(schema, dict):
                raise RuntimeError(f"Invalid MCP schema for {name}")
            TOOL_NAME_TO_URL[name] = url
            tools.append({
                "type": "function",
                "function": {
                    "name": name,
                    "description": tool.get("description", ""),
                    "parameters": deepcopy(schema),
                },
            })
    if allowed is not None:
        missing = allowed - {tool["function"]["name"] for tool in tools}
        if missing:
            raise RuntimeError("Wikipedia tools unavailable: " + ", ".join(sorted(missing)))
    return tools


# Mapping from model-hint tool names to actual MCP server URLs
# This helps the model use the right URL when it picks a conceptual tool name
TOOL_NAME_TO_URL: Dict[str, str] = {
    "web_search": f"{MCP_BASE}/mcp/web-search",
    "full-web-search": f"{MCP_BASE}/mcp/web-search",
    "get-web-search-summaries": f"{MCP_BASE}/mcp/web-search",
    "get-single-web-page-content": f"{MCP_BASE}/mcp/web-search",
    "wikipedia_search": f"{MCP_BASE}/mcp/wikipedia",
    "search": f"{MCP_BASE}/mcp/wikipedia",
    "readArticle": f"{MCP_BASE}/mcp/wikipedia",
    "current_time": f"{MCP_BASE}/mcp/time",
    "vlc_control": f"{MCP_BASE}/mcp/vlc",
    "open-in-vlc": f"{MCP_BASE}/mcp/vlc",
    "pdf_extract": f"{MCP_BASE}/mcp/pdf",
    "read_pdf_text": f"{MCP_BASE}/mcp/pdf",
    "read_pdf_images": f"{MCP_BASE}/mcp/pdf",
}


async def get_mcp_url(tool_name: str) -> Optional[str]:
    """Get the MCP server URL for a given tool name."""
    return TOOL_NAME_TO_URL.get(tool_name)


def tool_name_from_function(name: str) -> str:
    """The function name from the model IS the actual MCP tool name.

    No mapping needed — we now send the real tool names in the definitions.
    """
    return name
