import time
import uuid
from typing import Any, Dict, List, Optional

import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

if __package__:
    from .orchestrator import MODEL, LLAMA_URL_DIRECT, TEMPERATURE, MAX_TOKENS, run_messages
else:
    from orchestrator import MODEL, LLAMA_URL_DIRECT, TEMPERATURE, MAX_TOKENS, run_messages


app = FastAPI(title="IP Tool Orchestrator")


class ChatRequest(BaseModel):
    model: str
    messages: List[Dict[str, Any]] = Field(min_length=1)
    temperature: Optional[float] = Field(default=None, ge=0, le=2)
    max_tokens: Optional[int] = Field(default=None, gt=0)
    top_p: Optional[float] = Field(default=None, ge=0, le=1)
    stream: bool = False


@app.get("/v1/models")
async def list_models():
    return {
        "object": "list",
        "data": [
            {
                "id": MODEL,
                "object": "model",
                "created": 0,
                "owned_by": "local",
            }
        ],
    }


@app.post("/v1/chat/completions")
async def chat_completions(request: ChatRequest):
    if request.stream:
        raise HTTPException(
            status_code=400,
            detail="This endpoint currently supports stream=false only.",
        )

    if request.model != MODEL:
        raise HTTPException(
            status_code=400,
            detail=f"This service is configured for model: {MODEL}",
        )

    try:
        result = await run_messages(
            messages=request.messages,
            model_config={
                "api_endpoint": LLAMA_URL_DIRECT.removesuffix("/chat/completions"),
                "model_name": request.model,
            },
            temperature=TEMPERATURE if request.temperature is None else request.temperature,
            max_tokens=MAX_TOKENS if request.max_tokens is None else request.max_tokens,
            top_p=request.top_p,
            wikipedia_only=True,
        )
    except httpx.TimeoutException as exc:
        raise HTTPException(
            status_code=504,
            detail="The upstream service timed out.",
        ) from exc
    except httpx.HTTPError as exc:
        raise HTTPException(
            status_code=502,
            detail="The upstream service request failed; check server logs.",
        ) from exc

    except (RuntimeError, ValueError) as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    if result.get("error"):
        raise HTTPException(status_code=502, detail=result["error"])
    answer = result.get("final_answer")
    if not isinstance(answer, str) or not answer.strip():
        raise HTTPException(
            status_code=502,
            detail="The orchestrator did not produce a final answer.",
        )

    return {
        "id": f"chatcmpl-{uuid.uuid4().hex}",
        "object": "chat.completion",
        "created": int(time.time()),
        "model": request.model,
        "choices": [
            {
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": answer,
                },
                "finish_reason": "stop",
            }
        ],
    }
