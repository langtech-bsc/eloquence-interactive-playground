"""
LangGraph orchestrator for llama.cpp + MCP tools.

Uses LangGraph's StateGraph to build the agent loop:
  user message -> LLM (llama.cpp) -> decides on tool calls
    -> if tool_calls -> execute MCP tools -> feed results back -> LLM
    -> if no tool_calls -> return final answer

Usage:
  # Run single query
  python orchestrator.py --query "What time is it?"

  # Interactive mode
  python orchestrator.py

  # Dry run (no actual tool calls)
  python orchestrator.py --query "Search for Barcelona" --dry-run
"""

import os
import json
import uuid
import asyncio
import argparse
import logging
from typing import Any, Dict, List, Optional, TypedDict
from copy import deepcopy
from datetime import datetime

import httpx

from langgraph.graph import StateGraph, END, START

if __package__:
    from .mcp_tools import (
        build_tool_definitions,
        call_mcp_tool,
        get_mcp_url,
        tool_name_from_function,
        TOOLS_CONFIG,
    )
else:
    from mcp_tools import (
        build_tool_definitions,
        call_mcp_tool,
        get_mcp_url,
        tool_name_from_function,
        TOOLS_CONFIG,
    )

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "ERROR"),
    format="%(asctime)s %(levelname)s [orch] %(message)s",
)
log = logging.getLogger("orchestrator")

# ── Configuration ──────────────────────────────────────────────────────────────
LLAMA_URL_DIRECT = os.getenv("LLAMA_URL_DIRECT", "http://127.0.0.1:9000/v1/chat/completions")
MODEL = os.getenv("MODEL_NAME", "local-model")
MAX_MODEL_CALLS = int(
    os.getenv("MAX_MODEL_CALLS", os.getenv("MAX_TOOL_ITERATIONS", "8"))
)
TEMPERATURE = float(os.getenv("TEMPERATURE", "0.2"))
MAX_TOKENS = int(os.getenv("MAX_TOKENS", "8192"))
SESSION_FILE = os.getenv("SESSION_FILE", "orchestrator_sessions.json")
DEFAULT_SESSION_ID = os.getenv("PROXY_SESSION_ID", "f43a5146-cd21-406f-a93e-eb8f08370ba1")

# ── System message ────────────────────────────────────────────────────────────
def load_system_message() -> str:
    """Load the system message from system_message.txt."""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    system_msg_file = os.path.join(script_dir, "system_message.txt")
    with open(system_msg_file, encoding="utf-8") as f:
        return f.read().strip()


# ── LangGraph State ──────────────────────────────────────────────────────────
class AgentState(TypedDict):
    """State carried through the agent graph.

    messages: full conversation history (system + user + assistant + tool)
    iteration: how many LLM calls we've made
    pending_tool_calls: tool calls that need to be executed
    final_answer: set when the model gives a non-tool response
    error: set if something went wrong
    proxy_session_id: session_id returned by the llama-proxy for memory continuity
    """
    messages: List[Dict[str, Any]]
    iteration: int
    pending_tool_calls: List[Dict[str, Any]]
    final_answer: Optional[str]
    error: Optional[str]
    proxy_session_id: Optional[str]
    llm_config: Dict[str, Any]
    llm_url: str
    llm_api_key: Optional[str]
    tools: List[Dict[str, Any]]
    tool_urls: Dict[str, str]
    wikipedia_only: bool
    dry_run: bool


# ── Session management ────────────────────────────────────────────────────────
def load_session(session_id: str) -> List[Dict[str, Any]]:
    """Load conversation history from session file."""
    if os.path.exists(SESSION_FILE):
        with open(SESSION_FILE) as f:
            data = json.load(f)
            if session_id in data:
                return data[session_id].get("messages", [])
    return [
        {"role": "system", "content": load_system_message()}
    ]


def save_session(session_id: str, messages: List[Dict[str, Any]]):
    """Save conversation history to session file."""
    data = {}
    if os.path.exists(SESSION_FILE):
        with open(SESSION_FILE) as f:
            data = json.load(f)
    data[session_id] = {
        "messages": messages,
        "updated_at": datetime.now().isoformat(),
    }
    with open(SESSION_FILE, "w") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


# ── Helpers ────────────────────────────────────────────────────────────────────
def _build_proxy_messages(state: AgentState) -> List[Dict[str, Any]]:
    """Build messages to send to the proxy.

    When the proxy has a confirmed session (proxy_session_id was returned by
    the proxy in a previous response, not the fallback default), send only
    system + last user message so the proxy preserves its SQLite history
    and operational memory (facts, etc.).

    On the first call (proxy_session_id not yet confirmed by proxy), send the
    full local history so the proxy can bootstrap.
    """
    proxy_sid = state.get("proxy_session_id")

    # proxy_session_id was returned by the proxy itself => proxy already
    # has this session's SQLite history. Don't overwrite it.
    if proxy_sid and proxy_sid != DEFAULT_SESSION_ID:
        system_msgs = [m for m in state["messages"] if m["role"] == "system"]
        user_msgs = [m for m in state["messages"] if m["role"] == "user"]
        if user_msgs:
            return system_msgs + [user_msgs[-1]]
        return system_msgs

    # First call or proxy hasn't confirmed yet — send full history
    return state["messages"]


LLAMA_PROXY_BASE = os.getenv("LLAMA_PROXY_BASE", "http://127.0.0.1:9000")


async def fetch_proxy_memory(session_id: str) -> Dict[str, Any]:
    """Fetch operational memory (facts, summary) from the proxy."""
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            r = await client.get(f"{LLAMA_PROXY_BASE}/session/{session_id}")
            if r.status_code == 200:
                return r.json().get("memory", {})
    except Exception:
        pass
    return {}


async def save_proxy_memory(session_id: str, memory: Dict[str, Any]) -> None:
    """Save operational memory to the proxy via /checkpoint."""
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            await client.post(
                f"{LLAMA_PROXY_BASE}/session/{session_id}/checkpoint",
                json={"facts": memory.get("facts_state", [])},
            )
    except Exception:
        pass


# ── Node: call LLM ───────────────────────────────────────────────────────────
async def call_llm(state: AgentState) -> Dict[str, Any]:
    """Call llama.cpp and get the model response.

    Sends the current conversation + tool definitions to llama.cpp.
    Returns updated state with the model's response.
    """
    tools = state.get("tools")
    tool_urls = state.get("tool_urls", {})
    if tools is None:
        tools = await build_tool_definitions(wikipedia_only=state.get("wikipedia_only", False))
        tool_urls = {tool["function"]["name"]: await get_mcp_url(tool["function"]["name"])
                     for tool in tools}
    llm_config = state.get("llm_config")
    proxy_sid = state.get("proxy_session_id") or DEFAULT_SESSION_ID
    use_proxy = llm_config is None and os.getenv("USE_LLAMA_PROXY", "true") == "true"
    proxy_messages = deepcopy(_build_proxy_messages(state) if use_proxy else state["messages"])
    final_call = state["iteration"] >= MAX_MODEL_CALLS - 1
    if final_call:
        proxy_messages.append({
            "role": "system",
            "content": (
                "This is the final model call. Do not request tools. Answer now "
                "using only the evidence already present in the messages."
            ),
        })
    if use_proxy:
        memory = await fetch_proxy_memory(proxy_sid)
        facts = memory.get("facts_state", [])
        if facts:
            for message in proxy_messages:
                if message["role"] == "system":
                    message["content"] += f"\n\nUser facts: {facts}"
                    break

    payload = {
        **(llm_config if llm_config is not None else {
            "model": MODEL, "temperature": TEMPERATURE, "max_tokens": MAX_TOKENS,
        }),
        "messages": proxy_messages,
        "stream": False,
    }
    if use_proxy:
        payload["cache_prompt"] = True
    if tools and not final_call:
        payload["tools"] = tools
        payload["tool_choice"] = "auto"
    headers = {"X-Session-ID": proxy_sid} if use_proxy else {}

    api_key = state.get("llm_api_key")
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    llm_url = state.get("llm_url", LLAMA_URL_DIRECT)

    async with httpx.AsyncClient(timeout=300.0, headers=headers) as client:
        r = await client.post(llm_url, json=payload)
        if r.is_error:
            log.error("Model endpoint returned HTTP %s", r.status_code)
            r.raise_for_status()

    response = r.json()
    message = response["choices"][0]["message"]
    tool_calls = message.get("tool_calls", [])
    # Extract session_id from proxy response (non-streaming: under proxy.session_id)
    proxy_session_id = response.get("proxy", {}).get("session_id")

    updated = {
        "messages": state["messages"] + [message],
        "iteration": state["iteration"] + 1,
        "pending_tool_calls": [],
        "final_answer": None,
        "proxy_session_id": proxy_session_id or proxy_sid,
        "tools": tools,
        "tool_urls": tool_urls,
        "error": None,
    }

    if not tool_calls:
        answer = message.get("content")
        if isinstance(answer, str) and answer.strip():
            updated["final_answer"] = answer
        else:
            updated["error"] = "The model returned no answer or tool calls."
    elif updated["iteration"] >= MAX_MODEL_CALLS:
        updated["error"] = "The agent reached its model-call limit."
    else:
        updated["pending_tool_calls"] = tool_calls

    return updated


# ── Node: execute tools ──────────────────────────────────────────────────────
async def execute_tools(state: AgentState) -> Dict[str, Any]:
    """Execute pending tool calls and return results as tool messages.

    Each tool call is forwarded to the appropriate MCP server.
    """
    tool_calls = state.get("pending_tool_calls", [])
    tool_results = []

    for tc in tool_calls:
        func = tc.get("function", {})
        name = func.get("name", "")
        args_str = func.get("arguments", "{}")

        try:
            args = json.loads(args_str)
        except json.JSONDecodeError as exc:
            raise ValueError("Tool arguments contain invalid JSON.") from exc

        mcp_name = tool_name_from_function(name)
        mcp_url = state.get("tool_urls", {}).get(mcp_name)
        if not mcp_url:
            raise RuntimeError(f"The model requested an unavailable tool: {name}")
        if not isinstance(args, dict):
            raise ValueError("Tool arguments must be a JSON object.")
        if state.get("dry_run"):
            result_text = f"Dry run: would execute {mcp_name}"
        else:
            log.info("Executing tool: %s", mcp_name)
            result_text = await call_mcp_tool(mcp_url, mcp_name, args)

        tool_results.append({
            "role": "tool",
            "tool_call_id": tc["id"],
            "content": result_text,
        })
        log.info("  Tool [%s] -> %d chars", name, len(result_text))

    return {
        "messages": state["messages"] + tool_results,
        "pending_tool_calls": [],  # cleared after execution
        "proxy_session_id": state.get("proxy_session_id"),
    }


# ── Router: decide next step ─────────────────────────────────────────────────
def should_continue(state: AgentState) -> str:
    """Stop after a final answer or the maximum number of model calls."""
    if state.get("error") or state.get("final_answer"):
        return END

    if state["iteration"] >= MAX_MODEL_CALLS:
        return END

    if state.get("pending_tool_calls"):
        return "execute_tools"

    return "call_llm"


# ── Build the graph ──────────────────────────────────────────────────────────
def build_graph_ip(*, llm_node, tool_node, router):
    """Build IP's workflow using explicitly supplied behavior."""
    return build_graph(
        llm_node=llm_node,
        tool_node=tool_node,
        router=router,
    )
def build_graph(
    *,
    llm_node=None,
    tool_node=None,
    router=None,
):
    """Build the agent loop with optional caller-supplied behavior."""
    graph = StateGraph(AgentState)

    graph.add_node(
        "call_llm",
        call_llm if llm_node is None else llm_node,
    )
    graph.add_node(
        "execute_tools",
        execute_tools if tool_node is None else tool_node,
    )

    graph.add_edge(START, "call_llm")
    graph.add_edge("execute_tools", "call_llm")

    graph.add_conditional_edges(
        "call_llm",
        should_continue if router is None else router,
        {
            "execute_tools": "execute_tools",
            END: END,
            "call_llm": "call_llm",
        },
    )

    return graph.compile()

async def run_messages(
    messages: List[Dict[str, Any]],
    *,
    model_config: Dict[str, Any],
    temperature: float = 0.2,
    max_tokens: int = 512,
    top_p: Optional[float] = None,
    wikipedia_only: bool = False,
) -> Dict[str, Any]:
    """Run the agent loop with supplied conversation and model configuration."""
    if not messages:
        raise ValueError("messages must not be empty.")

    endpoint = str(model_config.get("api_endpoint") or "").rstrip("/")
    model_name = model_config.get("model_name")

    if not endpoint or not model_name:
        raise ValueError(
            "The model configuration requires api_endpoint and model_name."
        )

    if MAX_MODEL_CALLS < 1:
        raise ValueError("MAX_MODEL_CALLS must be at least 1.")

    llm_config = {
        "model": model_name,
        "temperature": temperature,
        "max_tokens": max_tokens,
    }
    if top_p is not None:
        llm_config["top_p"] = top_p

    initial_state: AgentState = {
        "messages": deepcopy(messages),
        "iteration": 0,
        "pending_tool_calls": [],
        "final_answer": None,
        "error": None,
        "proxy_session_id": None,
        "llm_config": llm_config,
        "llm_url": endpoint + "/chat/completions",
        "llm_api_key": model_config.get("api_key"),
        "wikipedia_only": wikipedia_only,
    }

    app = build_graph()
    result = await app.ainvoke(
        initial_state,
        config={"recursion_limit": 2 * MAX_MODEL_CALLS + 5},
    )

    # Return results without exposing the model credentials.
    return {
        "final_answer": result.get("final_answer"),
        "messages": result["messages"],
        "iteration": result["iteration"],
        "error": result.get("error"),
    }


# Backward-compatible name; both entry points use the same implementation.
run_messages_ip = run_messages

# ── Main orchestration function ──────────────────────────────────────────────
async def run_agent(user_input: str, session_id: Optional[str] = None,
                    dry_run: bool = False) -> Dict[str, Any]:
    """Run the full agent loop using LangGraph.

    Args:
        user_input: The user's message
        session_id: Optional session ID for conversation continuity
        dry_run: If True, simulate tool calls without executing them

    Returns:
        Dict with final_answer, iterations, and full conversation
    """
    if session_id is None:
        session_id = str(uuid.uuid4())

    # Load session history or start fresh
    history = load_session(session_id)
    history = history + [{"role": "user", "content": user_input}]

    # Initialize state
    initial_state: AgentState = {
        "messages": history,
        "iteration": 0,
        "pending_tool_calls": [],
        "final_answer": None,
        "error": None,
        "proxy_session_id": session_id,
        "dry_run": dry_run,
    }

    # Build and run graph
    app = build_graph()
    result = await app.ainvoke(initial_state, config={"recursion_limit": 2 * MAX_MODEL_CALLS + 5})

    # Save to session
    save_session(session_id, result["messages"])

    if result.get("final_answer"):
        log.info("=== Final answer (iteration %d) ===", result["iteration"])
        log.info("%s", result["final_answer"])
    elif result.get("error"):
        log.error(result["error"])

    return {
        "session_id": session_id,
        "iteration": result["iteration"],
        "answer": result.get("final_answer"),
        "error": result.get("error"),
        "messages": result["messages"],
    }


# ── CLI entry point ───────────────────────────────────────────────────────────
async def main():
    """Interactive CLI mode."""
    parser = argparse.ArgumentParser(description="LangGraph orchestrator for llama.cpp + MCP tools")
    parser.add_argument("--query", "-q", type=str, help="Single query to execute")
    parser.add_argument("--session", "-s", type=str, help="Session ID for conversation continuity")
    parser.add_argument("--dry-run", action="store_true", help="Simulate without executing tools")
    parser.add_argument("-v", "--verbose", action="store_true", help="Show verbose output (tool listing, debug logs)")
    args = parser.parse_args()

    if args.verbose:
        logging.getLogger("orchestrator").setLevel(logging.INFO)
        httpx_logger = logging.getLogger("httpx")
        httpx_logger.setLevel(logging.WARNING)

    if args.verbose:
        # Show available tools
        tools = await build_tool_definitions()
        print(f"\nAvailable MCP tools ({len(tools)}):")
        for t in tools:
            fname = t["function"]["name"]
            fdesc = t["function"]["description"]
            print(f"  * {fname}: {fdesc}")
        print()

    if args.query:
        result = await run_agent(args.query, session_id=args.session, dry_run=args.dry_run)
        if result.get("answer"):
            print(f"\nAssistant: {result['answer']}\n")
        elif result.get("error"):
            print(f"\nError: {result['error']}\n")
        return

    # Interactive mode
    session_id = args.session or str(uuid.uuid4())
    log.info("Session: %s", session_id)

    while True:
        try:
            user_input = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nBye!")
            break

        if not user_input:
            continue

        result = await run_agent(user_input, session_id=session_id)

        if result.get("answer"):
            print(f"\nAssistant: {result['answer']}\n")
        elif result.get("error"):
            print(f"\nError: {result['error']}\n")


if __name__ == "__main__":
    asyncio.run(main())
