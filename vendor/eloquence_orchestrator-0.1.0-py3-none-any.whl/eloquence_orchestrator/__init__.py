"""ELOQUENCE model and MCP tool orchestration."""
